fx_version 'adamant'
game 'gta5'

client_script 'game.lua'